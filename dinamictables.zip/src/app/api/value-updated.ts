export interface ValueUpdated {
  valId: any;
  field: string;
  value: string;
}
