export interface Cell {
  field: string;
  value: string;
  valueOut?: string;
  buttondt: any;
  raw: boolean;
  visible: boolean;
  editable: any;
  fieldid: boolean;
}
