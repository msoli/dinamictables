export interface CellStyles {
  tdClass?: string;
}
