export interface Search {
  field: string;
  value: string;
}
