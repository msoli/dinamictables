interface DateChanged {
  btnType: string;
  value: string;
}
