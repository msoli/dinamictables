export interface ApiParams {
  data?: () => any;
  setData?: () => void;
  selectedRows?: () => any;
  modifiedRows?: () => any;
}
