export interface ServerPagination {
  size_page: number;
  sort_dir: string;
  current_page: number;
  col_name: string;
}
