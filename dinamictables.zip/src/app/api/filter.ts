export interface Filter {
  field: string;
  change_event: any;
  type: string;
  data?: any;
}
